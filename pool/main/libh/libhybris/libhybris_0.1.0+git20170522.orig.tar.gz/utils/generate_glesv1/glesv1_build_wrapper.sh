#!/bin/sh
python generate_wrappers.py glesv1_functions.h > glesv1_wrapper.h
